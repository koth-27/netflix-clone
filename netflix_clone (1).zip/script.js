let modalPlayer;
let modalMuted = true;
let hideTimeout;
let progressInterval;

function onYouTubeIframeAPIReady() {
  modalPlayer = new YT.Player('trailer-frame', {
    height: '400',
    width: '100%',
    videoId: '',
    playerVars: { 'autoplay': 0, 'controls': 0, 'modestbranding': 1, 'rel': 0 },
  });
}

function extractYouTubeID(url) {
  const regex = /[?&]v=([^&#]*)|youtu\.be\/([^&#]*)|embed\/([^&#]*)/;
  const match = url.match(regex);
  return match ? (match[1] || match[2] || match[3]) : null;
}

fetch('movies.json')
  .then(res => res.json())
  .then(data => {
    const rowsContainer = document.getElementById('rows');
    data.categories.forEach((category, index) => {
      const section = document.createElement('section');
      section.className = 'row';
      section.innerHTML = `<h2>${category.name}</h2><div class="movie-list" id="row-${index}"></div>`;
      const movieList = section.querySelector('.movie-list');

      category.movies.forEach(movie => {
        const div = document.createElement('div');
        div.className = 'movie-card';
        div.innerHTML = `
          <div class="poster"><img src="${movie.thumbnail}" alt="${movie.title}"></div>
          <div class="preview">
            <iframe class="preview-iframe" src="" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
          </div>
          <p>${movie.title}</p>
          <button onclick="playTrailer('${movie.trailer}')">▶ Play</button>
        `;

        let hoverTimeout;
        const poster = div.querySelector('.poster');
        const preview = div.querySelector('.preview');
        const iframe = div.querySelector('.preview-iframe');
        let isMuted = true;

        div.addEventListener('mouseenter', () => {
          hoverTimeout = setTimeout(() => {
            poster.style.display = "none";
            preview.style.display = "block";
            iframe.src = `${movie.trailer}?autoplay=1&mute=${isMuted ? 1 : 0}&controls=0`;
          }, 1000);
        });

        div.addEventListener('mouseleave', () => {
          clearTimeout(hoverTimeout);
          poster.style.display = "block";
          preview.style.display = "none";
          iframe.src = "";
        });

        movieList.appendChild(div);
      });

      rowsContainer.appendChild(section);
    });
  });

function playTrailer(url) {
  const modal = document.getElementById('trailer-modal');
  modal.style.display = 'block';
  const videoId = extractYouTubeID(url);

  if (modalPlayer && modalPlayer.loadVideoById) {
    modalPlayer.loadVideoById({ videoId });
    modalPlayer.mute();
    document.getElementById('modal-mute-btn').textContent = "🔇 Unmute";
    document.getElementById('modal-play-btn').textContent = "⏸ Pause";
    showControls();
    modalPlayer.playVideo();

    clearInterval(progressInterval);
    progressInterval = setInterval(() => {
      if (modalPlayer.getDuration) {
        const duration = modalPlayer.getDuration();
        const current = modalPlayer.getCurrentTime();
        document.getElementById('progress').style.width = (current / duration) * 100 + "%";
      }
    }, 500);
  }
}

function closeTrailer() {
  document.getElementById('trailer-modal').style.display = 'none';
  if (modalPlayer && modalPlayer.stopVideo) modalPlayer.stopVideo();
  clearInterval(progressInterval);
  document.getElementById('progress').style.width = "0%";
}

const controls = document.getElementById('modal-controls');
const muteBtn = document.getElementById('modal-mute-btn');
const playBtn = document.getElementById('modal-play-btn');

muteBtn.addEventListener('click', () => {
  if (modalPlayer.isMuted()) {
    modalPlayer.unMute(); muteBtn.textContent = "🔊 Mute";
  } else {
    modalPlayer.mute(); muteBtn.textContent = "🔇 Unmute";
  }
  showControls();
});

playBtn.addEventListener('click', () => {
  const state = modalPlayer.getPlayerState();
  if (state === YT.PlayerState.PLAYING) {
    modalPlayer.pauseVideo(); playBtn.textContent = "▶ Play";
  } else {
    modalPlayer.playVideo(); playBtn.textContent = "⏸ Pause";
  }
  showControls();
});

function showControls() {
  controls.classList.remove('hidden');
  clearTimeout(hideTimeout);
  hideTimeout = setTimeout(() => controls.classList.add('hidden'), 3000);
}

document.getElementById('trailer-modal').addEventListener('mousemove', () => {
  if (document.getElementById('trailer-modal').style.display === 'block') showControls();
});
